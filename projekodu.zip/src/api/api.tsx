import axios from 'axios';
import { useDispatch, useSelector } from 'react-redux';
import { clearToken } from '../store/slices/auth/authSlice';
import { useRouteNavigator } from '../utils/RouteHelper';
import { IRootState } from '../store';

const api = axios.create({
    baseURL: 'http://kermes.test/api',
});

// Request Interceptor
api.interceptors.request.use(
    (config) => {
        const token = useSelector((state: IRootState) => state.auth.token); // Redux state üzerinden token alınıyor.
        const navigateToRoute = useRouteNavigator();

        if (!token) {
            // Token yoksa giriş sayfasına yönlendir
            navigateToRoute('Login');
            throw new Error('Token bulunamadı. Kullanıcı giriş yapmalıdır.');
        }

        config.headers.Authorization = `Bearer ${token}`;
        return config;
    },
    (error) => {
        return Promise.reject(error);
    }
);

// Response Interceptor
api.interceptors.response.use(
    (response) => response,
    (error) => {
        if (error.response && error.response.status === 401) {
            const dispatch = useDispatch();
            const navigateToRoute = useRouteNavigator();

            // Token'ı temizle
            dispatch(clearToken());

            // Kullanıcıyı yönlendir
            navigateToRoute('Login');
        }

        return Promise.reject(error);
    }
);

export default api;
