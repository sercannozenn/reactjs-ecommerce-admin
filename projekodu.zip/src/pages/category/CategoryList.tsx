const CategoryList = () => {

    return (
        <div>
            <h1>Category List</h1>
        </div>
    );
};

export default CategoryList;
